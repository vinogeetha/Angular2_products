import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router-deprecated';

@Component({
  selector: 'app-check',
  templateUrl: './check.component.html',
  styleUrls: ['./check.component.css']
})
export class CheckComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
goBack(){
    this.router.navigate(['/']);
  }
}